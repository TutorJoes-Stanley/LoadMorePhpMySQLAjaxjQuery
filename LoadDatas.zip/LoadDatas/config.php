<?php 
	$con=new mysqli("localhost","root","root","tutor");
?>